// package com.enviro.assessment.grad001.tebogosekwala.tebohosekwala;

// import org.junit.jupiter.api.Test;
// import org.springframework.boot.test.context.SpringBootTest;

// @SpringBootTest
// class TebohosekwalaApplicationTests {

// 	@Test
// 	void contextLoads() {
// 	}

// }
