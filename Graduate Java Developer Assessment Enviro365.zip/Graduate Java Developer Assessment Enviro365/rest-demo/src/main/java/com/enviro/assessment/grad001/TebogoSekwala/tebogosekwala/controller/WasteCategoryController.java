package com.enviro.assessment.grad001.tebogosekwala.tebogosekwala.controller;

import com.enviro.assessment.grad001.tebogosekwala.tebogosekwala.entity.WasteCategory;
import com.enviro.assessment.grad001.tebogosekwala.tebogosekwala.service.WasteCategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/waste-categories")
public class WasteCategoryController {
    private final WasteCategoryService service;

    public WasteCategoryController(WasteCategoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<WasteCategory> create(@RequestBody WasteCategory category) {
        return new ResponseEntity<>(service.save(category), HttpStatus.CREATED);
    }

    @GetMapping
    public List<WasteCategory> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<WasteCategory> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
