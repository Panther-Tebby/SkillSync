package com.enviro.assessment.grad001.TebogoSekwala;

public @interface GeneratedValue {

}
