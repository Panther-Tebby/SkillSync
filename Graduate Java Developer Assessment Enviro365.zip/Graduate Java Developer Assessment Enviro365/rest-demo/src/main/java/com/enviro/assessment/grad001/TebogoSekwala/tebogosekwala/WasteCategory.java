import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "waste_categories")
public class WasteCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String description;

    @OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
    private List<WasteItem> wasteItems;

    // Constructors
    // Default constructor
    public WasteCategory() {
    }

    // Constructor with parameters
    public WasteCategory(String name, String description) {
        this.name = name;
        this.description = description;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<WasteItem> getWasteItems() {
        return wasteItems;
    }

    public void setWasteItems(List<WasteItem> wasteItems) {
        this.wasteItems = wasteItems;
    }
}
