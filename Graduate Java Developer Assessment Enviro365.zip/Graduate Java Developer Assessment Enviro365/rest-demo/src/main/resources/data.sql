INSERT INTO WASTE_CATEGORY (name, description) VALUES ('Plastic', 'Recyclable plastic materials');
INSERT INTO WASTE_CATEGORY (name, description) VALUES ('Paper', 'Recyclable paper materials');